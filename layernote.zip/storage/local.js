import { supabase } from './supabase';
const CURRENT_STORAGE_VERSION = 3;
const DEFAULT_TOAST_DURATION = 5;
function keyForOwnerToken() {
    return 'ownerToken';
}
function keyForUsername() {
    return 'username';
}
function keyForLayer(layerId) {
    return `layer:${layerId}`;
}
function keyForAnnotation(layerId, annotationId) {
    return `annotation:${layerId}:${annotationId}`;
}
function keyForAnnotationsList(layerId) {
    return `annotations:${layerId}`;
}
function keyForVideoIndex(videoId) {
    return `video:${videoId}`;
}
export const LocalStorageManager = {
    async getOwnerToken() {
        const result = await chrome.storage.local.get(keyForOwnerToken());
        if (result[keyForOwnerToken()]) {
            return result[keyForOwnerToken()];
        }
        const newToken = crypto.randomUUID();
        await chrome.storage.local.set({ [keyForOwnerToken()]: newToken });
        return newToken;
    },
    async getUsername() {
        const result = await chrome.storage.local.get(keyForUsername());
        return result[keyForUsername()] || '';
    },
    async setUsername(name) {
        const sanitized = name.trim().substring(0, 50);
        await chrome.storage.local.set({ [keyForUsername()]: sanitized });
    },
    async findLayerByVideo(videoId) {
        const result = await chrome.storage.local.get(keyForVideoIndex(videoId));
        const layerId = result[keyForVideoIndex(videoId)];
        if (!layerId)
            return null;
        return this.getLayer(layerId);
    },
    async getLayer(layerId) {
        const result = await chrome.storage.local.get(keyForLayer(layerId));
        return result[keyForLayer(layerId)] ?? null;
    },
    async getAnnotationsForLayer(layerId) {
        const layer = await this.getLayer(layerId);
        if (!layer)
            return [];
        const keys = layer.annotationIds.map(id => keyForAnnotation(layerId, id));
        if (keys.length === 0)
            return [];
        const result = await chrome.storage.local.get(keys);
        return keys.map(k => result[k]).filter(Boolean);
    },
    async saveLayerLocally(layer, annotations) {
        const writes = {};
        writes[keyForLayer(layer.id)] = layer;
        writes[keyForVideoIndex(layer.youtubeVideoId)] = layer.id;
        annotations.forEach(ann => {
            writes[keyForAnnotation(layer.id, ann.id)] = ann;
        });
        await chrome.storage.local.set(writes);
    },
    async updateLayerSyncState(layerId, syncState) {
        const layer = await this.getLayer(layerId);
        if (!layer)
            return;
        layer.syncState = syncState;
        layer.updatedAt = new Date().toISOString();
        await chrome.storage.local.set({ [keyForLayer(layerId)]: layer });
    },
    async getUnsyncedLayers() {
        const allData = await chrome.storage.local.get(null);
        const layers = [];
        for (const key of Object.keys(allData)) {
            if (key.startsWith('layer:') && allData[key].syncState !== 'synced') {
                layers.push(allData[key]);
            }
        }
        return layers;
    },
    async fetchRemoteLayer(layerIdOrSlug) {
        console.log('[LocalStorageManager] fetchRemoteLayer called with:', layerIdOrSlug);
        try {
            const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(layerIdOrSlug);
            let query = supabase.from('layers').select('*');
            if (isUuid) {
                console.log('[LocalStorageManager] Detected UUID format');
                query = query.eq('id', layerIdOrSlug);
            }
            else {
                console.log('[LocalStorageManager] Detected Slug format');
                query = query.eq('slug', layerIdOrSlug);
            }
            const { data: layerData, error: layerError } = await query.single();
            if (layerError) {
                console.error('[LocalStorageManager] Supabase layer error:', JSON.stringify(layerError));
                return null;
            }
            if (!layerData) {
                console.warn('[LocalStorageManager] No layer data found for:', layerIdOrSlug);
                return null;
            }
            console.log('[LocalStorageManager] Layer data found:', layerData.id);
            const layerId = layerData.id;
            const { data: annData, error: annError } = await supabase
                .from('annotations')
                .select('*')
                .eq('layer_id', layerId);
            if (annError) {
                console.error('[LocalStorageManager] Supabase annotations error:', annError);
                return null;
            }
            console.log('[LocalStorageManager] Annotations found:', annData?.length || 0);
            const layer = {
                id: layerData.id,
                ownerToken: layerData.owner_token,
                ownerName: layerData.owner_name || '',
                youtubeVideoId: layerData.video_id,
                title: layerData.title,
                annotationIds: annData.map((a) => a.id),
                syncState: 'synced',
                createdAt: layerData.created_at,
                updatedAt: layerData.updated_at
            };
            const annotations = annData.map((a) => ({
                id: a.id,
                layerId: a.layer_id,
                timestampSeconds: a.timestamp_seconds,
                content: a.content,
                toastDurationSeconds: a.toast_duration_seconds,
                createdAt: a.created_at,
                updatedAt: a.updated_at
            }));
            return { layer, annotations };
        }
        catch {
            return null;
        }
    },
    queueBackgroundSync(_layerId) {
        try {
            chrome.runtime.sendMessage({ type: 'TRIGGER_SYNC' });
        }
        catch {
            // Extension context may be invalidated
        }
    },
    async runMigrationPipeline() {
        const data = await chrome.storage.local.get('storageVersion');
        const currentVersion = data.storageVersion ? Number(data.storageVersion) : 1;
        if (currentVersion >= CURRENT_STORAGE_VERSION)
            return;
        let migratoryState = await chrome.storage.local.get(null);
        if (currentVersion === 1) {
            migratoryState = this.migrateV1ToV2(migratoryState);
        }
        if (currentVersion < 3) {
            migratoryState = this.migrateV2ToV3(migratoryState);
        }
        migratoryState.storageVersion = CURRENT_STORAGE_VERSION;
        await chrome.storage.local.set(migratoryState);
    },
    migrateV2ToV3(oldState) {
        const updatedState = { ...oldState };
        const keys = Object.keys(oldState);
        for (const key of keys) {
            if (key.startsWith('layer:')) {
                const layer = oldState[key];
                if (layer && !('ownerName' in layer)) {
                    updatedState[key] = { ...layer, ownerName: '' };
                }
            }
            if (key.startsWith('annotation:')) {
                const ann = oldState[key];
                if (ann && !('toastDurationSeconds' in ann)) {
                    updatedState[key] = { ...ann, toastDurationSeconds: DEFAULT_TOAST_DURATION };
                }
            }
        }
        return updatedState;
    },
    migrateV1ToV2(oldState) {
        const updatedState = { ...oldState };
        const keys = Object.keys(oldState);
        keys.forEach(key => {
            if (key.startsWith('annotations:')) {
                const layerId = key.split(':')[1];
                const rawArray = oldState[key];
                delete updatedState[key];
                const indexKey = `layer:${layerId}`;
                if (updatedState[indexKey]) {
                    updatedState[indexKey].annotationIds = rawArray.map(a => a.id);
                }
                rawArray.forEach(annotation => {
                    updatedState[`annotation:${layerId}:${annotation.id}`] = annotation;
                });
            }
        });
        return updatedState;
    },
    async exportLayer(layerId) {
        const layer = await this.getLayer(layerId);
        if (!layer)
            return null;
        const annotations = await this.getAnnotationsForLayer(layerId);
        return { version: 3, layer, annotations };
    },
    async importLayer(payload) {
        const totalSize = JSON.stringify(payload).length;
        if (totalSize > 2 * 1024 * 1024) {
            throw new Error('Imported file exceeds 2 MB safety boundary.');
        }
        const layer = payload.layer;
        layer.annotationIds = payload.annotations.map(a => a.id);
        layer.syncState = 'queued';
        layer.updatedAt = new Date().toISOString();
        if (!layer.ownerName) {
            layer.ownerName = '';
        }
        const annotations = payload.annotations.map(a => ({
            ...a,
            toastDurationSeconds: a.toastDurationSeconds ?? DEFAULT_TOAST_DURATION,
        }));
        await this.saveLayerLocally(layer, annotations);
        this.queueBackgroundSync(layer.id);
    }
};
//# sourceMappingURL=local.js.map